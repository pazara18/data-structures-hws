# you can run calico using below script 
# put all your files in same directory

calico Data_Structures_HW3_Evaluation_Tests.t  --log
